({
    baseUrl: 'src/',
    mainConfigFile: 'src/regulex.js',
    out: 'dest/regulex.js',
    optimize: 'uglify2',
    wrap: false,
    include: ['libs/almond','regulex']
})
